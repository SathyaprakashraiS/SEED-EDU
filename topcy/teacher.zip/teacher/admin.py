from django.contrib import admin
from .models import *

# Register your models here.
admin.site.register(AddquizT)
admin.site.register(AddquestionT)
admin.site.register(QuizAnswer)
admin.site.register(MockPM)
admin.site.register(Assesedanswer)
#admin.site.register(MockAnswer)
